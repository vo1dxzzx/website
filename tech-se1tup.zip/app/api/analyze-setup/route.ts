import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { type NextRequest, NextResponse } from "next/server"

// Fallback responses for when API key is missing
const fallbackResponses = [
  `# Setup Analysis

Without being able to analyze your specific image (no API key available), here are some general recommendations that might enhance your setup:

## Potential Enhancements:
* **Lighting Options**: Bias lighting or RGB strips can reduce eye strain and add ambiance
* **Cable Management**: Solutions like cable sleeves or under-desk trays if needed
* **Desk Accessories**: Headphone stands, controller docks, or desk organizers
* **Personalization**: Plants, artwork, or decorative elements to make the space yours
* **Audio**: Desktop speakers or a DAC/Amp if you're using high-quality headphones
* **Comfort**: Wrist rests, ergonomic peripherals, or footrests for long sessions

These are general suggestions - your setup may already have some or all of these elements. For personalized recommendations based on your actual image, an OpenAI API key would be needed.`,

  `# Setup Recommendations

Note: These are general suggestions without seeing your specific setup (no API key available):

## Consider These Additions:
* **Desk Space Optimization**: Monitor arms, under-desk drawers, or wall mounting for peripherals
* **Productivity Tools**: Stream deck, macro pad, or secondary input devices
* **Aesthetics**: Consistent color scheme, custom keycaps, or themed accessories
* **Comfort Upgrades**: Ergonomic chair, desk mat, or adjustable desk if not already present
* **Tech Upgrades**: USB hub, wireless charger, or cable management solutions
* **Environment**: Proper lighting, sound dampening panels, or background elements for calls/streaming

Your setup may already include many of these elements. For recommendations based on your actual image, an OpenAI API key would be required.`,
]

export async function POST(request: NextRequest) {
  try {
    const { image } = await request.json()

    // Check if OpenAI API key exists
    const apiKey = process.env.OPENAI_API_KEY

    if (!apiKey) {
      console.log("No OpenAI API key found, using fallback response")
      // Return a random fallback response
      const randomResponse = fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)]
      return NextResponse.json({ analysis: randomResponse, usingFallback: true })
    }

    console.log("API key found, attempting image analysis...")

    // If API key exists, proceed with actual API call
    const { text } = await generateText({
      model: openai("gpt-4o"),
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this desk/gaming setup image in detail. Look at what's actually present and provide specific, actionable recommendations. Focus on:\n\n1. **What I can see**: Identify the components, layout, and current setup\n2. **Missing essentials**: What key components might enhance the setup\n3. **Ergonomic improvements**: Monitor height, chair position, keyboard/mouse placement\n4. **Aesthetic enhancements**: Color coordination, lighting, visual appeal\n5. **Cable management**: Current state and potential improvements\n6. **Lighting**: Current lighting situation and suggestions\n7. **Storage & organization**: Desk space optimization\n\nBe specific about what you observe in the image and avoid generic suggestions that don't apply to this particular setup. If something looks good already, mention that too!",
            },
            {
              type: "image",
              image: image,
            },
          ],
        },
      ],
    })

    console.log("Image analysis successful")
    return NextResponse.json({ analysis: text, usingFallback: false })
  } catch (error) {
    console.error("Error analyzing setup:", error)

    // More detailed error logging
    if (error instanceof Error) {
      console.error("Error message:", error.message)
      console.error("Error stack:", error.stack)
    }

    // Return a fallback response in case of any error
    const fallbackResponse = `# Setup Analysis Error

I encountered an issue while analyzing your image. Here are some general recommendations:

## Potential Enhancements:
* **Lighting**: Consider bias lighting or RGB strips for ambiance
* **Cable Management**: Organize cables with sleeves or under-desk solutions
* **Desk Organization**: Add stands, organizers, or storage solutions
* **Ergonomics**: Ensure proper monitor height and seating position
* **Personalization**: Add plants, artwork, or decorative elements

**Note**: There was a technical issue with the image analysis. Please try again or check that your API key is properly configured.`

    return NextResponse.json({
      analysis: fallbackResponse,
      usingFallback: true,
      error: error instanceof Error ? error.message : "Unknown error",
    })
  }
}
